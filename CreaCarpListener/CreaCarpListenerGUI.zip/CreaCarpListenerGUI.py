import os
import shutil
import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinterdnd2 import DND_FILES, TkinterDnD
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from PIL import Image, ImageTk
import sys

# Ruta base donde se crearán las carpetas
RUTA_BASE = r"Y:\2024-25\1.SAFATA-Entrada (Treballadors Servipoli)"
MONITORED_FOLDER = r"Y:\2024-25\1.SAFATA-Entrada (Treballadors Servipoli)"

def extraer_datos(pdf_path):
    """Extrae el nombre del estudiante y el tipo de convenio del PDF."""
    try:
        with fitz.open(pdf_path) as doc:
            texto = doc[0].get_text("text")  # Extrae texto de la primera página
        
        # Buscar nombre del estudiante
        nombre_completo = None
        for i, linea in enumerate(texto.split("\n")):
            if "Centro Docente:" in linea:
                if i + 1 < len(texto.split("\n")):
                    nombre_completo = texto.split("\n")[i + 1].strip()
                break  # Solo tomamos la primera coincidencia

        if not nombre_completo:
            raise ValueError("No se encontró el nombre del estudiante en el PDF.")

        # Separar apellidos y nombre
        partes_nombre = nombre_completo.split()
        if len(partes_nombre) < 3:
            if len(partes_nombre) == 2:
                nombre = partes_nombre[0].lower().capitalize()
                apellido1 = partes_nombre[1]
                apellido2 = ""
            else:
                raise ValueError("Nombre del estudiante no reconocido.")

        # Las últimas dos palabras son los apellidos
        else:
            apellido1 = partes_nombre[-2]
            apellido2 = f" {partes_nombre[-1]}"
            nombre = " ".join([parte.capitalize() for parte in partes_nombre[:-2]])

        # Buscar tipo de convenio (Curricular o Extracurricular)
        tipo_convenio = "Extra"
        if "curriculares" in texto:
            tipo_convenio = "Curr"

        # Formato final del nombre de la carpeta
        nombre_carpeta = f"{apellido1.upper()}{apellido2.upper()}, {nombre} - Conv {tipo_convenio}"
        return nombre_carpeta

    except Exception as e:
        return f"Error: {e}"

def procesar_pdf(pdf_path):
    """Crea una carpeta con el nombre basado en los datos del PDF y mueve el archivo allí."""
    nombre_carpeta = extraer_datos(pdf_path)
    if nombre_carpeta.startswith("Error"):
        messagebox.showerror("Error", nombre_carpeta)  # Mostrar mensaje de error
        return nombre_carpeta  # Si hay error, se devuelve el mensaje de error
    
    ruta_destino = os.path.join(RUTA_BASE, nombre_carpeta)
    
    try:
        # Crear la carpeta si no existe
        os.makedirs(ruta_destino, exist_ok=True)

        # Mover el archivo a la nueva carpeta
        nuevo_pdf_path = os.path.join(ruta_destino, os.path.basename(pdf_path))
        shutil.move(pdf_path, nuevo_pdf_path)

        # Renombrar el archivo PDF para que tenga el mismo nombre que la carpeta
        nuevo_nombre_pdf = os.path.join(ruta_destino, f"{nombre_carpeta}.pdf")
        os.rename(nuevo_pdf_path, nuevo_nombre_pdf)

        return f"✅ PDF movido y renombrado a: {nuevo_nombre_pdf}"

    except Exception as e:
        messagebox.showerror("Error al mover el archivo", str(e))  # Mostrar mensaje de error
        return f"Error al mover el archivo: {e}"

class PDFHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.lower().endswith(".pdf"):
            resultado = procesar_pdf(event.src_path)
            print(resultado)

class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip_window = None
        self.widget.bind("<Enter>", self.show_tip)
        self.widget.bind("<Leave>", self.hide_tip)

    def show_tip(self, event=None):
        if self.tip_window or not self.text:
            return
        x, y, _cx, _cy = self.widget.bbox("insert")
        x = x + self.widget.winfo_rootx() + 25
        y = y + self.widget.winfo_rooty() + 25
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(tw, text=self.text, justify=tk.LEFT,
                         background="#ffffe0", relief=tk.SOLID, borderwidth=1,
                         font=("tahoma", "8", "normal"))
        label.pack(ipadx=1)

    def hide_tip(self, event=None):
        tw = self.tip_window
        self.tip_window = None
        if tw:
            tw.destroy()

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("CreaCarp UPE INF")
        self.root.geometry("600x420")  # Ajustar el tamaño de la ventana

        # Obtener la ruta del directorio actual
        if getattr(sys, 'frozen', False):
            # Si se está ejecutando como un ejecutable
            self.base_path = sys._MEIPASS
        else:
            # Si se está ejecutando como un script
            self.base_path = os.path.abspath(".")

        # Cargar el icono
        self.root.iconbitmap(os.path.join(self.base_path, r"assets\upv.ico"))

        # Cargar la imagen
        self.img = Image.open(os.path.join(self.base_path, r"assets\titulo_etsinf.png"))
        self.img = self.img.resize((600, 100), Image.LANCZOS)  # Ajustar el tamaño de la imagen
        self.photo = ImageTk.PhotoImage(self.img)
        
        # Mostrar la imagen en la cabecera
        self.label_img = tk.Label(root, image=self.photo)
        self.label_img.pack(pady=10)
        
        self.observer = None
        self.monitored_folder = ""
        self.ruta_base = ""

        self.label_origen = tk.Label(root, text="Ruta de origen:")
        self.label_origen.pack(pady=5)
        
        # Frame para la entrada de ruta de origen y el signo de interrogación
        self.frame_origen = tk.Frame(root)
        self.frame_origen.pack(pady=5)
        self.entry_origen = tk.Entry(self.frame_origen, width=50)
        self.entry_origen.pack(side=tk.LEFT)
        self.label_origen_help = tk.Label(self.frame_origen, text="?", fg="blue", cursor="hand2")
        self.label_origen_help.pack(side=tk.LEFT, padx=5)
        ToolTip(self.label_origen_help, "Selecciona la carpeta que deseas monitorear para nuevos archivos PDF.")
        
        self.button_origen = tk.Button(root, text="Seleccionar", command=self.seleccionar_origen)
        self.button_origen.pack(pady=5)

        self.label_destino = tk.Label(root, text="Ruta de destino:")
        self.label_destino.pack(pady=5)
        
        # Frame para la entrada de ruta de destino y el signo de interrogación
        self.frame_destino = tk.Frame(root)
        self.frame_destino.pack(pady=5)
        self.entry_destino = tk.Entry(self.frame_destino, width=50)
        self.entry_destino.pack(side=tk.LEFT)
        self.label_destino_help = tk.Label(self.frame_destino, text="?", fg="blue", cursor="hand2")
        self.label_destino_help.pack(side=tk.LEFT, padx=5)
        ToolTip(self.label_destino_help, "Selecciona la carpeta donde se crearán las nuevas carpetas basadas en los datos del PDF.")
        
        self.button_destino = tk.Button(root, text="Seleccionar", command=self.seleccionar_destino)
        self.button_destino.pack(pady=5)

        self.button_iniciar = tk.Button(root, text="Iniciar", command=self.iniciar_observador, state=tk.NORMAL, bg="green", fg="white")
        self.button_iniciar.pack(pady=10)
        self.button_detener = tk.Button(root, text="Detener", command=self.detener_observador, state=tk.DISABLED, bg="lightgray", fg="gray")
        self.button_detener.pack(pady=10)

        # Agregar el texto "C. R. U." en la esquina inferior derecha
        self.label_cru = tk.Label(root, text="- C. R. U.", fg="gray")
        self.label_cru.place(relx=1.0, rely=1.0, anchor='se', x=-10, y=-10)

    def seleccionar_origen(self):
        self.monitored_folder = filedialog.askdirectory()
        self.entry_origen.delete(0, tk.END)
        self.entry_origen.insert(0, self.monitored_folder)

    def seleccionar_destino(self):
        self.ruta_base = filedialog.askdirectory()
        self.entry_destino.delete(0, tk.END)
        self.entry_destino.insert(0, self.ruta_base)

    def iniciar_observador(self):
        if not self.monitored_folder or not self.ruta_base:
            messagebox.showerror("Error", "Debe seleccionar las rutas de origen y destino.")
            return

        global RUTA_BASE
        RUTA_BASE = self.ruta_base

        event_handler = PDFHandler()
        self.observer = Observer()
        self.observer.schedule(event_handler, self.monitored_folder, recursive=False)
        self.observer.start()
        messagebox.showinfo("Información", "Observador iniciado.")
        messagebox.showinfo("Información", "El script solo funcionará con PDFs de formato correcto. Si el archivo es un escaneado o una imagen, no se creará correctamente la carpeta. Tampoco funciona con rescisiones o modificaciones.")
        
        self.button_iniciar.config(state=tk.DISABLED, bg="lightgray", fg="gray")
        self.button_detener.config(state=tk.NORMAL, bg="red", fg="white")

    def detener_observador(self):
        if self.observer:
            self.observer.stop()
            self.observer.join()
            messagebox.showinfo("Información", "Observador detenido.")
            
            self.button_iniciar.config(state=tk.NORMAL, bg="green", fg="white")
            self.button_detener.config(state=tk.DISABLED, bg="lightgray", fg="gray")

if __name__ == "__main__":
    root = TkinterDnD.Tk()
    app = App(root)
    root.mainloop()